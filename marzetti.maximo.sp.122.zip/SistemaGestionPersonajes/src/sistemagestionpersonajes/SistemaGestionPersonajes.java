/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestionpersonajes;

import config.RutaArchivos;
import model.Personaje;
import model.RolPersonaje;
import persistence.ColeccionPersonajes;

public class SistemaGestionPersonajes {
    public static void main(String[] args) {

        try {
            ColeccionPersonajes<Personaje> coleccion = new ColeccionPersonajes<>();

            coleccion.agregar(new Personaje(1, "Arthas", "Blizzard", RolPersonaje.TANQUE));
            coleccion.agregar(new Personaje(2, "Zelda Mage", "Nintendo", RolPersonaje.MAGO));
            coleccion.agregar(new Personaje(3, "Shadow Archer", "Sega", RolPersonaje.ARQUERO));
            coleccion.agregar(new Personaje(4, "MedBot 2.0", "Valve", RolPersonaje.SANADOR));
            coleccion.agregar(new Personaje(5, "Tech Engineer", "Capcom", RolPersonaje.INGENIERO));
            
            // Mostrar todos los personajes
            System.out.println("Personajes:");
            coleccion.paraCadaElemento(p -> System.out.println(p));
            
            // Filtrar por rol MAGO
            System.out.println("\nPersonajes MAGO:");
            coleccion.filtrar(p -> p.getRol() == RolPersonaje.MAGO).forEach(System.out::println);
            
            /// Filtrar por nombre que contenga "Shadow"
            System.out.println("\nPersonajes que contienen 'Shadow':");
            coleccion.filtrar(p -> p.getNombre().contains("Shadow")).forEach(System.out::println);
            
            // Ordenar por ID (orden natural)
            System.out.println("\nPersonajes ordenados por ID:");
            coleccion.ordenar((p1, p2) -> Integer.compare(p1.getId(), p2.getId()));
            coleccion.paraCadaElemento(System.out::println);
            
            // Ordenar personajes por nombre
            System.out.println("\nPersonajes ordenados por nombre:");
            coleccion.ordenar((p1, p2) -> p1.getNombre().compareTo(p2.getNombre()));
            coleccion.paraCadaElemento(System.out::println);
            
            // Guardar en archivo binario
            coleccion.guardarEnArchivo(RutaArchivos.getPathBINString());
            
            // Cargar desde archivo binario
            ColeccionPersonajes<Personaje> cargado = new ColeccionPersonajes<>();
            cargado.cargarDesdeArchivo(RutaArchivos.getPathBINString());
            System.out.println("\nPersonajes cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);
            
            // Guardar en archivo CSV
            coleccion.guardarEnCSV(RutaArchivos.getPathCSVString());
            
            // Cargar desde archivo CSV
            cargado.cargarDesdeCSV(RutaArchivos.getPathCSVString(), linea -> Personaje.fromCSV(linea));;
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }


    }

}
