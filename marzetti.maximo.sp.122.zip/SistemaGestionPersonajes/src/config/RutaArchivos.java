/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author maxim
 */
public interface RutaArchivos {
    
    static final String BASE = "src/resources/";
    static final String FILE_CSV = "personajes.csv";
    static final String FILE_BIN = "personajes.bin";
    
    static Path getPathCSV() {
        return Paths.get(BASE, FILE_CSV);
    }
    static Path getPathBIN() {
        return Paths.get(BASE, FILE_BIN);
    }
    
    static String getPathCSVString() {
        return getPathCSV().toString();
    }
    
    static String getPathBINString() {
        return getPathBIN().toString();
    }
}
