/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

import interfaces.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author maxim
 */
public class ColeccionPersonajes < T extends CSVSerializable & Serializable & Comparable<T> > {
    
    private List<T> elementos;

    public ColeccionPersonajes() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        return elementos.get(indice);
    }
    
    public void eliminar(int indice) {
        elementos.remove(indice);
    }

    // Método para iterar cada elemento
    public void paraCadaElemento(Consumer<T> accion) {
        elementos.forEach(accion);
    }

    // Filtrado: Retorna una nueva lista con los elementos que cumplen la condición
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    // Ordenamiento por Comparator
    public void ordenar(Comparator<T> comparador) {
        this.elementos.sort(comparador);
    }

    // ARCHIVOS BINARIOS
    public void guardarEnArchivo(String ruta) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        } catch (IOException ex) {
            System.err.println("Error al guardar: " + ex.getMessage());
        }
    }
    
    public void cargarDesdeArchivo(String ruta) throws ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            this.elementos = (List<T>) ois.readObject();
        } catch (IOException ex) {
            System.err.println("Error al cargar: " + ex.getMessage());
        }
    }

    // --- ARCHIVOS CSV ---
    public void guardarEnCSV(String ruta) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                bw.write(elemento.toCSV());
                bw.newLine();
            }
        } catch (IOException ex) {
            System.err.println("Error al guardar: " + ex.getMessage());
        }
    }

    // Carga CSV genérica: Recibe la ruta y una función (Lambda) para convertir String -> T
    public void cargarDesdeCSV(String ruta, Function<String, T> transformador) {
        this.elementos.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T objeto = transformador.apply(linea);
                    this.elementos.add(objeto);
                }
            }
        } catch (IOException ex) {
            System.err.println("Error al cargar: " + ex.getMessage());
        }
    }
}
